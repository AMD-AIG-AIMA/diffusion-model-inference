import torch
from rocm_groupnorm import ROCMGroupNorm

class OPTGroupNorm(torch.nn.GroupNorm):

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.rocm_group_norm = ROCMGroupNorm()

    def forward(self, input : torch.Tensor, use_torch = False):
        if use_torch:
            return  super().forward(input)
        y = self.rocm_group_norm.run(
            input,
            self.num_groups,
            self.weight,
            self.bias,
            self.eps)
        assert y is not None
        return y
